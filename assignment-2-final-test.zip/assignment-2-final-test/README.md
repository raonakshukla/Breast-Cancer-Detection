# assignment-2

## Installation
- all the file ran on python 3.10.12 with scikit-learn==1.2.2